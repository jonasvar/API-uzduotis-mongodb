const express = require('express');
const router = express.Router();
const Post = require('../models/Post');


// GET
// HOME...
router.get('', async (req, res) => {
    try {
        const locals = {
            title: "Mano tinklaraštis",
            description: "Tinklaraštis sukurtas naudojant NodeJs, Express ir MongoDb."
        }
  
        let perPage = 10 //Nurodo kiek įrašu rodyti pagrindineme puslapyje...
        let page = req.query.page || 1
  
        const data = await Post.aggregate([ { $sort: { createdAt: -1 } } ])
            .skip(perPage * page - perPage)
            .limit(perPage)
            .exec()
  
        const count = await Post.countDocuments({})
        const nextPage = parseInt(page) + 1
        const hasNextPage = nextPage <= Math.ceil(count / perPage)
  
        res.render('index', { 
            locals,
            data,
            current: page,
            nextPage: hasNextPage ? nextPage : null,
            currentRoute: '/'
        })
    } catch (error) {
        console.log(error)
    }
})
  

// (Home - Nauji straipsniai) jeigu nenori daryti perėjimo į senesnius straipsnius nautoti šita.(Nes dabar home puslapyje rodo tik po 10 straipsnių)...
// router.get('', async (req, res) => {
//     const locals = {
//         title: "Mano tinklaraštis",
//         description: "Tinklaraštis sukurtas naudojant NodeJS, Express & MongoDb."
//     }
//     try {
//         const data = await Post.find()
//         res.render('index', {locals, data})
//     } catch (error) {
//         console.log(error)
//     }
// })



// GET
// Post : id...
router.get('/post/:id', async (req, res) => {
    try {
        let slug = req.params.id
        const data = await Post.findById({ _id: slug })
  
        const locals = {
            title: data.title,
            description: "Tinklaraštis sukurtas naudojant NodeJs, Express ir MongoDb.",
        }
        res.render('post', { 
            locals,
            data,
            currentRoute: `/post/${slug}`
        })
    } catch (error) {
        console.log(error)
    }
})



//  POST 
//  Post - search...
router.post('/search', async (req, res) => { 
    try {
        const locals = {
            title: "Ieškoti",
            description: "Tinklaraštis sukurtas naudojant NodeJs, Express ir MongoDb."
        }
  
        let searchTerm = req.body.searchTerm
        const searchNoSpecialChar = searchTerm.replace(/[^a-zA-Z0-9 ]/g, "")
  
        const data = await Post.find({
            $or: [
                { title: { $regex: new RegExp(searchNoSpecialChar, 'i') }},
                { body: { $regex: new RegExp(searchNoSpecialChar, 'i') }}
            ]
        })
        res.render("search", {
            data,
            locals,
            currentRoute: '/'
        })
    } catch (error) {
        console.log(error)
    }
})



//Apie...
router.get('/about', (req, res) => {
    res.render('about', {
        currentRoute: '/about'
    })
})

//Kontaktai...
router.get('/contact', (req, res) => {
    res.render('contact', {
        currentRoute: '/contact'
    })
})

module.exports = router    


/////////////////////////////////// Šia info isikeliam į mongo db...////////////////////////////////////////
// function insertPostData () {
//     Post.insertMany([
//       {
//         title: "Kaip pradėjau kurti savo tinklaraštį, kokia buvo viso to pradžia",
//         body: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam sint dolorum, explicabo unde expedita, tempora in quos adipisci neque, error dolorem repudiandae facilis inventore mollitia culpa consectetur nostrum harum blanditiis itaque natus nihil architecto beatae. Enim earum dicta vitae itaque!"
//       },
//       {
//         title: "Mano kelionės ir nuotikiai jose",
//         body: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam sint dolorum, explicabo unde expedita, tempora in quos adipisci neque, error dolorem repudiandae facilis inventore mollitia culpa consectetur nostrum harum blanditiis itaque natus nihil architecto beatae. Enim earum dicta vitae itaque!"
//       },
//       {
//         title: "Kaip sužinoti koks kontentas yra populerus?",
//         body: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam sint dolorum, explicabo unde expedita, tempora in quos adipisci neque, error dolorem repudiandae facilis inventore mollitia culpa consectetur nostrum harum blanditiis itaque natus nihil architecto beatae. Enim earum dicta vitae itaque!"
//       },
//       {
//         title: "Nuo ko pradėti kuriant savo verslą",
//         body: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam sint dolorum, explicabo unde expedita, tempora in quos adipisci neque, error dolorem repudiandae facilis inventore mollitia culpa consectetur nostrum harum blanditiis itaque natus nihil architecto beatae. Enim earum dicta vitae itaque!"
//       },
//       {
//         title: "Nesiklausykite kitu, klausykite saves, kaip to išmokti?",
//         body: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam sint dolorum, explicabo unde expedita, tempora in quos adipisci neque, error dolorem repudiandae facilis inventore mollitia culpa consectetur nostrum harum blanditiis itaque natus nihil architecto beatae. Enim earum dicta vitae itaque!"
//       },
//       {
//         title: "Išmok programuoti! Pradėk nuo šiu dalyku",
//         body: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam sint dolorum, explicabo unde expedita, tempora in quos adipisci neque, error dolorem repudiandae facilis inventore mollitia culpa consectetur nostrum harum blanditiis itaque natus nihil architecto beatae. Enim earum dicta vitae itaque!"
//       },
//       {
//         title: "Tapk programuotoju, išmok javascript!",
//         body: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam sint dolorum, explicabo unde expedita, tempora in quos adipisci neque, error dolorem repudiandae facilis inventore mollitia culpa consectetur nostrum harum blanditiis itaque natus nihil architecto beatae. Enim earum dicta vitae itaque!"
//       },
//       {
//         title: "Mokykis mongo db pagrindų",
//         body: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam sint dolorum, explicabo unde expedita, tempora in quos adipisci neque, error dolorem repudiandae facilis inventore mollitia culpa consectetur nostrum harum blanditiis itaque natus nihil architecto beatae. Enim earum dicta vitae itaque!"
//       },
//       {
//         title: "React ir typescript",
//         body: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam sint dolorum, explicabo unde expedita, tempora in quos adipisci neque, error dolorem repudiandae facilis inventore mollitia culpa consectetur nostrum harum blanditiis itaque natus nihil architecto beatae. Enim earum dicta vitae itaque!"
//       },
//       {
//         title: "Sukurk savo pirmajį puslapį",
//         body: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsam sint dolorum, explicabo unde expedita, tempora in quos adipisci neque, error dolorem repudiandae facilis inventore mollitia culpa consectetur nostrum harum blanditiis itaque natus nihil architecto beatae. Enim earum dicta vitae itaque!"
//       },
//     ])
// }
// insertPostData();